<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $heading ?></title>
    </head>
    <body style="background:rgb(231, 231, 231)">
        <div style="text-align:center;padding:10% 0; font-family:'Arial'">
            <h1 style="font-size:80px; color:rgb(173, 172, 172)"></h1>
            <h2 style="font-size: 20px; font-weight:300; margin-top:-50px; color:rgb(195, 195, 195)">
                <i style="font-size:18px"><p><?php echo $message; ?></p></i> Teitra Mega Web Application
            </h2>
        </div>
    </body>
</html>

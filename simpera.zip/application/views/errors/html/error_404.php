<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $heading ?></title>
    </head>
    <body style="background:rgb(231, 231, 231)">
        <div style="text-align:center;padding:10% 0; font-family:'Arial'">
            <h1 style="font-size:80px; color:rgb(173, 172, 172)"><?php echo $heading ?></h1>
            <h2 style="font-size: 20px; font-weight:300; margin-top:-40px; color:rgb(195, 195, 195)">
            	<?php echo $message; ?>
                <i style="font-size:18px">Teitra Mega Web Application</i> 
            </h2>
        </div>
    </body>
</html>

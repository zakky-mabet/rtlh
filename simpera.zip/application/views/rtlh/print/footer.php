		<small style="font-size: 9px;" class="prit-at">
			Dicetak oleh <strong><?php echo $this->session->userdata('ADMIN')->nama ?></strong> pada <?php echo date_id('Y-m-d', TRUE).date(' H:i A') ?>
		</small>
	</div>
	<div class="pagebreak"></div>
   	</body>
</html>